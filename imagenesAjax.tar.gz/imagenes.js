function insertarImagenes() {

    var objeto_peticion=new XMLHttpRequest();
    objeto_peticion.onreadystatechange=function() {
            if (objeto_peticion.status==200 && objeto_peticion.readyState==4)
        {
            var lista_imagenes=objeto_peticion.responseText.split(",");
            for(i=0;i<lista_rutas.length;i++)
            {
                var objeto_imagen=document.createElement("img");
                document.getElementById("contenedor_imagenes").appendChild(objeto_imagen);
                objeto_imagen.src=lista_imagenes[i];

            }
        }

    objeto_peticion.open("GET","Fotillos.txt");
    objeto_peticion.send();

}